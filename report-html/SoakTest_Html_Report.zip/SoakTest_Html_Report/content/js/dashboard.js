/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 99.77832172311778, "KoPercent": 0.22167827688221278};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.9977665259486287, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.9978278816093976, 500, 1500, "03-PUT API"], "isController": false}, {"data": [0.9977259293684491, 500, 1500, "05-DELETE API"], "isController": false}, {"data": [0.9978930841728664, 500, 1500, "04-PATCH API"], "isController": false}, {"data": [0.9976792544745958, 500, 1500, "02-POST API"], "isController": false}, {"data": [0.9977065047764236, 500, 1500, "01-GET API "], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 1108363, 2457, 0.22167827688221278, 2.8619820401799436, 0, 29714, 2.0, 8.0, 16.0, 47.0, 163.17071120455185, 113.43333772855004, 40.32293484614236], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["03-PUT API", 221673, 479, 0.21608405173386022, 2.9518434811636856, 0, 29714, 2.0, 8.0, 15.0, 48.0, 32.63453263041049, 23.416359517089578, 7.918791866624145], "isController": false}, {"data": ["05-DELETE API", 221629, 502, 0.22650465417431834, 2.849604519264102, 0, 28402, 2.0, 7.0, 15.0, 46.0, 32.62820389193528, 23.510878923033644, 8.107333482951711], "isController": false}, {"data": ["04-PATCH API", 221651, 463, 0.20888694388926737, 2.8485953142552876, 0, 28456, 2.0, 8.0, 16.0, 49.0, 32.6313706703821, 23.47502403221886, 8.045729338254173], "isController": false}, {"data": ["02-POST API", 221696, 509, 0.2295936778290993, 2.9106704676674813, 0, 22277, 2.0, 7.0, 15.0, 46.0, 32.63802918690386, 23.45621789827395, 7.982207132857504], "isController": false}, {"data": ["01-GET API ", 221714, 504, 0.2273198805668564, 2.7492084397014542, 0, 1501, 2.0, 8.0, 16.0, 46.0, 32.640313939655, 19.5760989016904, 8.269301088876597], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["The operation lasted too long: It took 1,159 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 1, 0.0407000407000407, 9.022314891420952E-5], "isController": false}, {"data": ["The operation lasted too long: It took 1,040 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 1, 0.0407000407000407, 9.022314891420952E-5], "isController": false}, {"data": ["The operation lasted too long: It took 22,277 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 1, 0.0407000407000407, 9.022314891420952E-5], "isController": false}, {"data": ["The operation lasted too long: It took 1,074 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 1, 0.0407000407000407, 9.022314891420952E-5], "isController": false}, {"data": ["The operation lasted too long: It took 1,103 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 1, 0.0407000407000407, 9.022314891420952E-5], "isController": false}, {"data": ["The operation lasted too long: It took 1,255 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 1, 0.0407000407000407, 9.022314891420952E-5], "isController": false}, {"data": ["The operation lasted too long: It took 1,112 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 1, 0.0407000407000407, 9.022314891420952E-5], "isController": false}, {"data": ["The operation lasted too long: It took 1,560 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 1, 0.0407000407000407, 9.022314891420952E-5], "isController": false}, {"data": ["The operation lasted too long: It took 28,456 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 1, 0.0407000407000407, 9.022314891420952E-5], "isController": false}, {"data": ["The operation lasted too long: It took 1,267 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 1, 0.0407000407000407, 9.022314891420952E-5], "isController": false}, {"data": ["The operation lasted too long: It took 1,157 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 1, 0.0407000407000407, 9.022314891420952E-5], "isController": false}, {"data": ["The operation lasted too long: It took 28,402 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 1, 0.0407000407000407, 9.022314891420952E-5], "isController": false}, {"data": ["The operation lasted too long: It took 1,314 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 1, 0.0407000407000407, 9.022314891420952E-5], "isController": false}, {"data": ["The operation lasted too long: It took 1,336 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 1, 0.0407000407000407, 9.022314891420952E-5], "isController": false}, {"data": ["The operation lasted too long: It took 1,183 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 1, 0.0407000407000407, 9.022314891420952E-5], "isController": false}, {"data": ["The operation lasted too long: It took 1,050 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 2, 0.0814000814000814, 1.8044629782841903E-4], "isController": false}, {"data": ["The operation lasted too long: It took 1,447 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 1, 0.0407000407000407, 9.022314891420952E-5], "isController": false}, {"data": ["The operation lasted too long: It took 1,061 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 1, 0.0407000407000407, 9.022314891420952E-5], "isController": false}, {"data": ["The operation lasted too long: It took 1,403 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 1, 0.0407000407000407, 9.022314891420952E-5], "isController": false}, {"data": ["The operation lasted too long: It took 1,430 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 1, 0.0407000407000407, 9.022314891420952E-5], "isController": false}, {"data": ["The operation lasted too long: It took 1,262 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 1, 0.0407000407000407, 9.022314891420952E-5], "isController": false}, {"data": ["Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: localhost:8000 failed to respond", 2395, 97.47659747659748, 0.21608444164953178], "isController": false}, {"data": ["The operation lasted too long: It took 1,203 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 1, 0.0407000407000407, 9.022314891420952E-5], "isController": false}, {"data": ["The operation lasted too long: It took 1,182 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 1, 0.0407000407000407, 9.022314891420952E-5], "isController": false}, {"data": ["The operation lasted too long: It took 1,272 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 1, 0.0407000407000407, 9.022314891420952E-5], "isController": false}, {"data": ["The operation lasted too long: It took 29,714 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 1, 0.0407000407000407, 9.022314891420952E-5], "isController": false}, {"data": ["The operation lasted too long: It took 1,066 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 1, 0.0407000407000407, 9.022314891420952E-5], "isController": false}, {"data": ["The operation lasted too long: It took 1,044 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 1, 0.0407000407000407, 9.022314891420952E-5], "isController": false}, {"data": ["The operation lasted too long: It took 1,025 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 1, 0.0407000407000407, 9.022314891420952E-5], "isController": false}, {"data": ["The operation lasted too long: It took 1,018 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 1, 0.0407000407000407, 9.022314891420952E-5], "isController": false}, {"data": ["The operation lasted too long: It took 1,389 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 1, 0.0407000407000407, 9.022314891420952E-5], "isController": false}, {"data": ["The operation lasted too long: It took 1,129 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 1, 0.0407000407000407, 9.022314891420952E-5], "isController": false}, {"data": ["The operation lasted too long: It took 1,107 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 1, 0.0407000407000407, 9.022314891420952E-5], "isController": false}, {"data": ["The operation lasted too long: It took 1,579 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 1, 0.0407000407000407, 9.022314891420952E-5], "isController": false}, {"data": ["The operation lasted too long: It took 1,260 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 1, 0.0407000407000407, 9.022314891420952E-5], "isController": false}, {"data": ["The operation lasted too long: It took 1,439 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 1, 0.0407000407000407, 9.022314891420952E-5], "isController": false}, {"data": ["The operation lasted too long: It took 1,510 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 1, 0.0407000407000407, 9.022314891420952E-5], "isController": false}, {"data": ["The operation lasted too long: It took 22,251 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 1, 0.0407000407000407, 9.022314891420952E-5], "isController": false}, {"data": ["The operation lasted too long: It took 1,167 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 1, 0.0407000407000407, 9.022314891420952E-5], "isController": false}, {"data": ["The operation lasted too long: It took 1,189 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 1, 0.0407000407000407, 9.022314891420952E-5], "isController": false}, {"data": ["The operation lasted too long: It took 1,576 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 1, 0.0407000407000407, 9.022314891420952E-5], "isController": false}, {"data": ["The operation lasted too long: It took 1,393 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 1, 0.0407000407000407, 9.022314891420952E-5], "isController": false}, {"data": ["The operation lasted too long: It took 1,239 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 1, 0.0407000407000407, 9.022314891420952E-5], "isController": false}, {"data": ["The operation lasted too long: It took 1,254 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 1, 0.0407000407000407, 9.022314891420952E-5], "isController": false}, {"data": ["The operation lasted too long: It took 1,038 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 2, 0.0814000814000814, 1.8044629782841903E-4], "isController": false}, {"data": ["The operation lasted too long: It took 1,191 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 1, 0.0407000407000407, 9.022314891420952E-5], "isController": false}, {"data": ["The operation lasted too long: It took 1,317 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 1, 0.0407000407000407, 9.022314891420952E-5], "isController": false}, {"data": ["The operation lasted too long: It took 1,127 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 1, 0.0407000407000407, 9.022314891420952E-5], "isController": false}, {"data": ["The operation lasted too long: It took 1,138 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 1, 0.0407000407000407, 9.022314891420952E-5], "isController": false}, {"data": ["The operation lasted too long: It took 1,143 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 1, 0.0407000407000407, 9.022314891420952E-5], "isController": false}, {"data": ["The operation lasted too long: It took 1,028 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 2, 0.0814000814000814, 1.8044629782841903E-4], "isController": false}, {"data": ["The operation lasted too long: It took 1,288 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 1, 0.0407000407000407, 9.022314891420952E-5], "isController": false}, {"data": ["The operation lasted too long: It took 1,039 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 1, 0.0407000407000407, 9.022314891420952E-5], "isController": false}, {"data": ["The operation lasted too long: It took 1,307 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 1, 0.0407000407000407, 9.022314891420952E-5], "isController": false}, {"data": ["The operation lasted too long: It took 28,633 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 1, 0.0407000407000407, 9.022314891420952E-5], "isController": false}, {"data": ["The operation lasted too long: It took 1,164 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 1, 0.0407000407000407, 9.022314891420952E-5], "isController": false}, {"data": ["The operation lasted too long: It took 1,501 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 2, 0.0814000814000814, 1.8044629782841903E-4], "isController": false}, {"data": ["The operation lasted too long: It took 1,408 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 1, 0.0407000407000407, 9.022314891420952E-5], "isController": false}, {"data": ["The operation lasted too long: It took 1,411 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 1, 0.0407000407000407, 9.022314891420952E-5], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 1108363, 2457, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: localhost:8000 failed to respond", 2395, "The operation lasted too long: It took 1,050 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 2, "The operation lasted too long: It took 1,038 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 2, "The operation lasted too long: It took 1,028 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 2, "The operation lasted too long: It took 1,501 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 2], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": ["03-PUT API", 221673, 479, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: localhost:8000 failed to respond", 468, "The operation lasted too long: It took 1,239 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 1, "The operation lasted too long: It took 1,028 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 1, "The operation lasted too long: It took 29,714 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 1, "The operation lasted too long: It took 1,066 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 1], "isController": false}, {"data": ["05-DELETE API", 221629, 502, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: localhost:8000 failed to respond", 487, "The operation lasted too long: It took 28,402 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 1, "The operation lasted too long: It took 1,038 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 1, "The operation lasted too long: It took 1,336 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 1, "The operation lasted too long: It took 1,389 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 1], "isController": false}, {"data": ["04-PATCH API", 221651, 463, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: localhost:8000 failed to respond", 454, "The operation lasted too long: It took 1,050 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 2, "The operation lasted too long: It took 1,028 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 1, "The operation lasted too long: It took 1,439 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 1, "The operation lasted too long: It took 28,456 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 1], "isController": false}, {"data": ["02-POST API", 221696, 509, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: localhost:8000 failed to respond", 497, "The operation lasted too long: It took 1,254 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 1, "The operation lasted too long: It took 1,157 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 1, "The operation lasted too long: It took 1,025 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 1, "The operation lasted too long: It took 22,277 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 1], "isController": false}, {"data": ["01-GET API ", 221714, 504, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: localhost:8000 failed to respond", 489, "The operation lasted too long: It took 1,159 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 1, "The operation lasted too long: It took 1,040 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 1, "The operation lasted too long: It took 1,044 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 1, "The operation lasted too long: It took 1,183 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 1], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
